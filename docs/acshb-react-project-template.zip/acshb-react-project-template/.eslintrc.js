module.exports = {
  env: {
    browser: true,
    es6: true,
    node: true
  },
  extends: ["eslint:recommended", "plugin:react/recommended"],
  globals: {
    Atomics: "readonly",
    SharedArrayBuffer: "readonly"
  },
  parser: "babel-eslint",
  parserOptions: {
    ecmaFeatures: {
      jsx: true
    },
    ecmaVersion: 2018,
    sourceType: "module",
    allowImportExportEverywhere: true
  },
  plugins: ["react", "react-hooks"],
  rules: {
    "import/no-unresolved": 0,
    "import/namespace": 0,
    "import/extensions": [0, "never"],
    "semi": "error",
    "quotes": ["error", "double"],
    "no-console": [1, { "allow": ["warn", "error", "info"] }],
    "react/jsx-filename-extension": [1, { "extensions": [".js", ".jsx"] }],
    "no-debugger": 1,
    "no-var": 2,
    "no-unused-vars": [1, { "args": "none" }],
    "react/prop-types": 1,
    "react/sort-comp": 2,
    "react/no-unescaped-entities": 0,
    "react-hooks/rules-of-hooks": "error",
    "react-hooks/exhaustive-deps": "warn"
  }
};
