# acshb-react-project-template

Bu proje [Create React App] paketi ile oluşturulmuştur.(https://github.com/facebook/create-react-app).

## Proje Klasör Yapısı
```
public/
    favicon.ico
    index.html
    manifest.json
    logo192.png
    logo512.png
    robots.txt

src/
    actions/
    assets/
    components/
    fonts/
    layouts/
    local/
    routes/
    reducers/
    styles/
    services/
    views/
    utils/
    -App.js
    -index.js
    -serviceWorker.js
.gitignore
package.json
README.md
```

## Projede kullanılan paketler
```
    "@testing-library/jest-dom": "4.2.4",
    "@testing-library/react": "9.3.2",
    "@testing-library/user-event": "7.1.2",
    "acshb-react-common": "file:acshb-react-common-1.4.0.tgz",
    "node-sass": "4.13.1",
    "react": "16.13.0",
    "react-dom": "16.13.0",
    "react-redux": "7.2.0",
    "react-scripts": "3.4.0",
    "redux": "4.0.5",
    "redux-form": "8.3.1",
    "redux-thunk": "2.3.0"
```

## Projede Kullanılan Geliştirici Paketleri
```
    "eslint": "6.8.0",
    "eslint-plugin-react": "7.19.0"
```

## Gereksinimler

-Projede acshb-react-common framework paketini kulanmak için **npm i redux-form** paketi mutlaka kurulmalıdır. (redux-form paketi redux, react-redux ve redux-thunk paketleri ile birlikte çalışıyor.)

-acshb-react-common içerisindeki global.scss stil dosyası mutlaka **Sass css dosyası içerisinden çağırılmalıdır**

## Bazı Komutlar

Projede bu komutları çalıştırarak;

### `npm start`

Uygulamayı geliştirici modunda çalıştırır.<br>
[http://localhost:3000](http://localhost:3000) adresine giderek uygulamayı görebilirsiniz.

Projede değişiklik yaptığınızda değişiklik, gerçek zamanlı olarak yansıyacaktır.<br>
Bir hata oluştuğunda commanline aracılığı ile hataları görebilirsiniz.

### `npm test`

Uygulamadaki testleri çalıştırır ve commandline aracı ile test sonuçlarını ekrana yazdırır.

### `npm run build`

Uygulamanın derkenmiş halini `build` klasörüne çıkartır.<br>

Komut çıktı olarak tüm javascript ve css dosylarını sıkıştıracak, küçültecek ve asset dosyalarının isimlerini hash edecektir.<br>
İşlem bittikten sonra ilgili klasöre giderek deployment işlemi yapılabilir.

Daha fazla bilgi için [deployment](https://facebook.github.io/create-react-app/docs/deployment) sayfasına bakılabilir.

### `npm run lint`

Bu komut kod kalitesi gereği **.eslintrc.js** dosyasına tanımlanmış olan kural setleri ile yazılan kodları denetleyerek uyarı ve/veya hataları ekranda gösterir.

### `npm run lint:fix`

Bu komut kod kalitesi gereği **.eslintrc.js** dosyasına tanımlanmış olan kural setleri çerçevesinde kodları otomatik olarak düzeltir.

## Daha Fazlası İçin

Daha fazla bilgi için [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started) sayfasına bakılabilir.