import { lazy } from "react";

/**
 * Lazyload yapısı.
 */
const Login = lazy(() => import("./views/Login"));

export default Login;
