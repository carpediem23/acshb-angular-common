import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { useTranslation } from "react-i18next";
import {
  ACSHBSection,
  ACSHBForm,
  FormField,
  ACSHBButton
} from "acshb-react-common/components";
import * as validations from "acshb-react-common/utils/validation";
import { login } from "../business/action";
import logo from "../../../assets/armali-logo-tr.svg";
import "./style.scss";

/**
 * Login modülü.
 *
 * @param {func}    login     Redux login methodu credential bilgilerini parametre alarak login işlemini başlatır
 * @param {boolean} loading   Redux post operasyonu başladığında http durumunu takip etmek için kullanılır.
 * @param {object}  response   Login post operasyonundan dönecek objedir.
 * @param {object}  error      Login post operasyonunda bir hata meydana geldiğinde ulaşılabilecek hata nesnesi.
 */
const Login = props => {
  const { t } = useTranslation();
  const { loading, login } = props;

  const onLoginSubmit = e => {
    login(e);
  };

  return (
    <ACSHBSection>
      <div className="login-view">
        <div className="container">
          <div className="row justify-content-center align-items-center">
            <div className="col-md-8 bg-white border shadow jumbotron">
              <div className="row">
                <div className="col">
                  <img
                    className="img-responsive d-block m-auto"
                    width="250"
                    src={logo}
                    alt="Login Logo"
                  />
                </div>
              </div>
              <div className="row">
                <div className="col text-center">
                  <h2 className="font-weight-light mb-5">
                    {t("modules.login.title")}
                  </h2>
                </div>
              </div>
              <div className="row justify-content-center">
                <div className="col-md-10">
                  <ACSHBForm name="loginForm" onSubmit={onLoginSubmit}>
                    <div className="form-row">
                      <div className="form-group col-md-12">
                        <FormField
                          name="username"
                          className="form-control"
                          type="text"
                          placeholder={t(
                            "modules.login.input-username-placeholder"
                          )}
                          validate={[
                            validations.required,
                            validations.email,
                            validations.maxLength32
                          ]}
                        />
                      </div>
                    </div>
                    <div className="form-row">
                      <div className="form-group col-md-12">
                        <FormField
                          name="password"
                          className="form-control"
                          type="password"
                          placeholder={t(
                            "modules.login.input-password-placeholder"
                          )}
                          validate={[
                            validations.required,
                            validations.minLength2,
                            validations.maxLength32
                          ]}
                        />
                      </div>
                    </div>
                    <div className="form-row">
                      <div className="form-group col-md-12">
                        <ACSHBButton
                          className="btn btn-primary btn-block"
                          loading={loading}
                          disabled={loading}
                          type="submit"
                        >
                          {t("modules.login.button-title")}
                        </ACSHBButton>
                      </div>
                    </div>
                  </ACSHBForm>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ACSHBSection>
  );
};

const mapStateToProps = state => {
  return {
    response: state.login.response,
    loading: state.login.loading,
    error: state.login.error
  };
};

const mapDispatchToProps = dispatch => {
  return {
    login: credentials => dispatch(login(credentials))
  };
};

Login.propTypes = {
  /**
   * redux login methodu.
   */
  login: PropTypes.func,
  /**
   * redux login işlemi sürüyor mu?
   */
  loading: PropTypes.bool,
  /**
   * Login post response.
   */
  response: PropTypes.object,
  /**
   * Login post işleminde hata var ise hata obejesi.
   */
  error: PropTypes.object
};

Login.defaultProps = {
  loading: false,
  response: null,
  error: null
};

export default connect(mapStateToProps, mapDispatchToProps)(Login);
