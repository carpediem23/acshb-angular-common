import { postLogin } from "./loginService";
import UserService from "../../../services/UserService";
import TokenService from "../../../services/TokenService";

/**
 * Redux action tipleridir.
 */
export const types = {
  LOGIN_BEGIN: "LOGIN_BEGIN",
  LOGIN_SUCCESS: "LOGIN_SUCCESS",
  LOGIN_FAILURE: "LOGIN_FAILURE"
};

/**
 * Login action methodudur.
 *
 * @param {object} credential Login ekranından gelen kimlik bilgileridir.
 */
export const login = credential => {
  return dispatch => {
    dispatch(loginBegin());
    return postLogin(credential)
      .then(response => {
        UserService.setUser(response.data);
        TokenService.setToken("{token_string}");
        dispatch(loginSuccess(response));
        window.location = "/";
      })
      .catch(error => {
        dispatch(loginFailure(error));
      });
  };
};

/**
 * Login operasyonu başladığında durumu takip edebilmek için hazırlanmıştır ve 'login' methodundan hemen sonra tetiklenmelidir.
 */
export const loginBegin = () => ({
  type: types.LOGIN_BEGIN
});

/**
 * Login operasyonu başarı ile tamamlandığında durumu takip edebilmek için hazırlanmıştır ve 'loginBegin' methodundan hemen sonra tetiklenmelidir.
 */
export const loginSuccess = response => ({
  type: types.LOGIN_SUCCESS,
  payload: { response }
});

/**
 * Login operasyonu başarısızlık ile tamamlanamadığında durumu takip edebilmek için hazırlanmıştır ve http methodunun catch methodunun içinde çağırılmalıdır.
 */
export const loginFailure = res => ({
  type: types.LOGIN_FAILURE,
  payload: res.response
});
