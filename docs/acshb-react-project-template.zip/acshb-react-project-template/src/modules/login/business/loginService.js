import { postRequest } from "../../../services/HttpService";

/**
 *
 * @param {object} credentials Kullanıcı kimlik bilgileri {username: "username", password: "password"}
 */
export function postLogin(credentials) {
  const url = "/login";
  return postRequest(url, credentials);
}
