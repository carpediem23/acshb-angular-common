import { types } from "./action";

const initialState = {
  response: null,
  loading: false,
  error: null
};

/**
 * HTTP operasyonları için kullanılacak olan reducer.
 */
export default function login(state = initialState, action) {
  switch (action.type) {
    case types.LOGIN_BEGIN:
      /**
       * login operasyonu başladı, yükleniyor...
       */
      return {
        response: null,
        loading: true,
        error: null
      };

    case types.LOGIN_SUCCESS:
      /**
       * login operasyonu başarı ile tamamlandı, loading özelliği false yapılabilir.
       */
      return {
        error: null,
        loading: false,
        response: action.payload.response
      };

    case types.LOGIN_FAILURE:
      /**
       * login operasyonu başarı ile tamamlanamadı, loading özelliği false yapılabilir ve hata nesnesi buradan yakalanabilir.
       */
      console.error(action.payload);
      return {
        loading: false,
        error: action.payload,
        response: null
      };

    default:
      return state;
  }
}
