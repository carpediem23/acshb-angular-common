import { lazy } from "react";

/**
 * Lazyload yapısı.
 */
const Users = lazy(() => import("./views/Users"));

export default Users;
