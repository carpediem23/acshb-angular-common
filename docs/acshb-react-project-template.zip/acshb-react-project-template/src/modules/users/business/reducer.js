import { types } from "./action";

const initialState = {
  response: [],
  loading: false,
  error: null
};

/**
 * HTTP operasyonları için kullanılacak olan reducer.
 */
export default function user(state = initialState, action) {
  switch (action.type) {
    case types.GET_USERS_BEGIN:
      /**
       * fetchUsersAll operasyonu başladı, yükleniyor...
       */
      return {
        response: [],
        loading: true,
        error: null
      };

    case types.GET_USERS_SUCCESS:
      /**
       * fetchUsersAll operasyonu başarı ile tamamlandı, loading özelliği false yapılabilir.
       */
      return {
        error: null,
        loading: false,
        response: action.payload.data.items
      };

    case types.GET_USERS_FAILURE:
      /**
       * fetchUsersAll operasyonu başarı ile tamamlanamadı, loading özelliği false yapılabilir ve hata nesnesi buradan yakalanabilir.
       */
      return {
        loading: false,
        error: action.payload,
        response: []
      };

    case types.SEARCH_USERS_BEGIN:
      /**
       * fetchUsers operasyonu başladı, yükleniyor...
       */
      return {
        response: [],
        loading: true,
        error: null
      };

    case types.SEARCH_USERS_SUCCESS:
      /**
       * fetchUsers operasyonu başarı ile tamamlandı, loading özelliği false yapılabilir.
       */
      return {
        error: null,
        loading: false,
        response: action.payload.data.items
      };

    case types.SEARCH_USERS_FAILURE:
      /**
       * fetchUsers operasyonu başarı ile tamamlanamadı, loading özelliği false yapılabilir ve hata nesnesi buradan yakalanabilir.
       */
      return {
        loading: false,
        error: action.payload,
        response: []
      };

    case types.POST_USERS_BEGIN:
      /**
       * postUser operasyonu başladı, yükleniyor...
       */
      return {
        response: null,
        loading: true,
        error: null
      };

    case types.POST_USERS_SUCCESS:
      /**
       * postUser operasyonu başarı ile tamamlandı, loading özelliği false yapılabilir.
       */
      return {
        error: null,
        loading: false,
        response: null
      };

    case types.POST_USERS_FAILURE:
      /**
       * postUser operasyonu başarı ile tamamlanamadı, loading özelliği false yapılabilir ve hata nesnesi buradan yakalanabilir.
       */
      return {
        loading: false,
        error: action.payload,
        response: []
      };
    default:
      return state;
  }
}
