import { getRequest, postRequest } from "../../../services/HttpService";

/**
 * Kullanıcı http get servis methodu.
 */
export function fetchAllUsers() {
  const url = "/users";
  return getRequest(url);
}

export function fetchUsers(page, sizePerPage, sortField, sortOrder, search) {
  const url = `/users?page=${page}&limit=${sizePerPage}&sortBy=${sortField}&order=${sortOrder}&${
    search && search !== null ? `search=${search}` : ""
  }`;
  return getRequest(url);
}

export function postUser(user) {
  const url = "/users";
  return postRequest(url, user);
}
