import { fetchUsers, postUser, fetchAllUsers } from "./userService";

/**
 * Redux action tipleridir.
 */
export const types = {
  GET_USERS_BEGIN: "GET_USERS_BEGIN",
  GET_USERS_SUCCESS: "GET_USERS_SUCCESS",
  GET_USERS_FAILURE: "GET_USERS_FAILURE",
  POST_USERS_BEGIN: "POST_USERS_BEGIN",
  POST_USERS_SUCCESS: "POST_USERS_SUCCESS",
  POST_USERS_FAILURE: "POST_USERS_FAILURE",
  SEARCH_USERS_BEGIN: "SEARCH_USERS_BEGIN",
  SEARCH_USERS_SUCCESS: "SEARCH_USERS_SUCCESS",
  SEARCH_USERS_FAILURE: "SEARCH_USERS_FAILURE"
};

/**
 * Users get action methodudur.
 */
export const getUsers = () => {
  return dispatch => {
    dispatch(getUsersBegin());
    return fetchAllUsers()
      .then(response => {
        dispatch(getUsersSuccess(response));
      })
      .catch(error => {
        dispatch(getUsersFailure(error));
      });
  };
};

/**
 * fetchUsersAll operasyonu başladığında durumu takip edebilmek için hazırlanmıştır ve 'getUsers' methodundan hemen sonra tetiklenmelidir.
 */
export const getUsersBegin = () => ({
  type: types.GET_USERS_BEGIN
});

/**
 * fetchUsersAll operasyonu başarı ile tamamlandığında durumu takip edebilmek için hazırlanmıştır ve 'getUsersBegin' methodundan hemen sonra tetiklenmelidir.
 */
export const getUsersSuccess = response => ({
  type: types.GET_USERS_SUCCESS,
  payload: response
});

/**
 * fetchUsersAll operasyonu başarısızlık ile tamamlanamadığında durumu takip edebilmek için hazırlanmıştır ve http methodunun catch methodunun içinde çağırılmalıdır.
 */
export const getUsersFailure = response => ({
  type: types.GET_USERS_FAILURE,
  payload: response
});

/**
 * Search users get action methodudur.
 */
export const searchUsers = (
  page,
  sizePerPage,
  sortField,
  sortOrder,
  search
) => {
  return dispatch => {
    dispatch(searchUsersBegin());
    return fetchUsers(page, sizePerPage, sortField, sortOrder, search)
      .then(response => {
        dispatch(searchUsersSuccess(response));
      })
      .catch(error => {
        dispatch(searchUsersFailure(error));
      });
  };
};

/**
 * fetchUsers operasyonu başladığında durumu takip edebilmek için hazırlanmıştır ve 'searchUsers' methodundan hemen sonra tetiklenmelidir.
 */
export const searchUsersBegin = () => ({
  type: types.SEARCH_USERS_BEGIN
});

/**
 * fetchUsers operasyonu başarı ile tamamlandığında durumu takip edebilmek için hazırlanmıştır ve 'searchUsersBegin' methodundan hemen sonra tetiklenmelidir.
 */
export const searchUsersSuccess = response => ({
  type: types.SEARCH_USERS_SUCCESS,
  payload: response
});

/**
 * fetchUsers operasyonu başarısızlık ile tamamlanamadığında durumu takip edebilmek için hazırlanmıştır ve http methodunun catch methodunun içinde çağırılmalıdır.
 */
export const searchUsersFailure = response => ({
  type: types.SEARCH_USERS_FAILURE,
  payload: response
});

/**
 * Users post action methodudur.
 */
export const createUser = user => {
  return dispatch => {
    dispatch(getUsersBegin());
    return postUser(user)
      .then(response => {
        dispatch(getUsersSuccess(response));
      })
      .catch(error => {
        dispatch(getUsersFailure(error));
      });
  };
};

/**
 * postUser operasyonu başladığında durumu takip edebilmek için hazırlanmıştır ve 'createUser' methodundan hemen sonra tetiklenmelidir.
 */
export const postUserBegin = () => ({
  type: types.POST_USERS_BEGIN
});

/**
 * postUser operasyonu başarı ile tamamlandığında durumu takip edebilmek için hazırlanmıştır ve 'postUserBegin' methodundan hemen sonra tetiklenmelidir.
 */
export const postUserSuccess = response => ({
  type: types.POST_USERS_SUCCESS,
  payload: response
});

/**
 * postUser operasyonu başarısızlık ile tamamlanamadığında durumu takip edebilmek için hazırlanmıştır ve http methodunun catch methodunun içinde çağırılmalıdır.
 */
export const postUserFailure = response => ({
  type: types.POST_USERS_FAILURE,
  payload: response
});
