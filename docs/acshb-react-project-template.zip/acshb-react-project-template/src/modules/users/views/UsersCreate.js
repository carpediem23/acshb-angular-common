import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import {
  ACSHBButton,
  ACSHBForm,
  FormField
} from "acshb-react-common/components";
import * as validations from "acshb-react-common/utils/validation";
import { createUser } from "../business/action";

const UserCreate = props => {
  const onSubmit = form => {
    const { createUser } = props;

    createUser(form);
  };

  return (
    <div className="users">
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            <p className="lead">Kullancı Ekle</p>
            <ACSHBForm name="userCreateForm" onSubmit={onSubmit}>
              <div className="form-row">
                <div className="form-group col-md-12">
                  <FormField
                    name="firstname"
                    className="form-control"
                    type="text"
                    label="İsim"
                    placeholder=" "
                    validate={[validations.required, validations.maxLength32]}
                  />
                </div>
                <div className="form-group col-md-12">
                  <FormField
                    name="lastname"
                    className="form-control"
                    type="text"
                    label="Soyisim"
                    placeholder=" "
                    validate={[validations.required, validations.maxLength32]}
                  />
                </div>
                <div className="form-group col-md-12">
                  <FormField
                    name="city"
                    className="form-control"
                    type="text"
                    label="Şehir"
                    placeholder=" "
                    validate={[validations.required, validations.maxLength32]}
                  />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-12 justify-content-between d-flex">
                  <ACSHBButton
                    className="btn btn-secondary"
                    type="button"
                    onClick={() => window.history.back()}
                  >
                    Geri
                  </ACSHBButton>
                  <ACSHBButton className="btn btn-primary" type="submit">
                    Ekle
                  </ACSHBButton>
                </div>
              </div>
            </ACSHBForm>
          </div>
        </div>
      </div>
    </div>
  );
};

const mapStateToProps = state => {
  return {
    response: state.user.response,
    loading: state.user.loading,
    error: state.user.error
  };
};

const mapDispatchToProps = dispatch => {
  return {
    createUser: user => dispatch(createUser(user))
  };
};

UserCreate.propTypes = {
  /**
   * redux postUser methodu.
   */
  createUser: PropTypes.func,
  /**
   * redux postUser işlemi sürüyor mu?
   */
  loading: PropTypes.bool,
  /**
   * postUser post response.
   */
  response: PropTypes.array,
  /**
   * postUser post işleminde hata var ise hata obejesi.
   */
  error: PropTypes.object
};

UserCreate.defaultProps = {
  loading: false,
  response: null,
  error: null
};

export default connect(mapStateToProps, mapDispatchToProps)(UserCreate);
