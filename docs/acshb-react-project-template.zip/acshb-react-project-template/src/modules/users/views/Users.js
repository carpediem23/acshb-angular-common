import React from "react";
import { Switch, Route } from "react-router-dom";
import UserList from "./UserList";
import UserCreate from "./UsersCreate";
import "./style.scss";

const Users = () => {
  return (
    <div className="users">
      <Switch>
        <Route path="/kullanicilar/ekle" component={UserCreate} />
        <Route path="/kullanicilar" component={UserList} />
      </Switch>
    </div>
  );
};

export default Users;
