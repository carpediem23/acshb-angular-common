import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { ACSHBDatatable, ACSHBFrame } from "acshb-react-common/components";
import { searchUsers } from "../business/action";
import { NoDataIndicator } from "../../../components";

const UserList = props => {
  const { response, loading, getUsers } = props;
  const [tableConfig, setTableConfig] = useState({
    page: 1,
    sizePerPage: 10,
    sortField: "firstname",
    sortOrder: "asc",
    search: ""
  });
  const buttonFormatter = (cell, row) => {
    return (
      <div className="btn-group">
        <button
          className="btn btn-danger"
          type="button"
          onClick={() => alert(row.id + " numaralı kullanıcı silinecek.")}
        >
          <span className="acshb-icon-trash"></span>
        </button>
        <button
          className="btn btn-info"
          type="button"
          onClick={() => alert(row.id + " numaralı kullanıcı düzenlenecek.")}
        >
          <span className="acshb-icon-edit"></span>
        </button>
      </div>
    );
  };
  const columns = [
    {
      dataField: "id",
      text: "Id"
    },
    {
      dataField: "firstname",
      text: "Adı",
      sort: true
    },
    {
      dataField: "lastname",
      text: "Soyadı"
    },
    {
      dataField: "city",
      text: "Şehir"
    },
    {
      dataField: "",
      text: "İşlemler",
      formatter: buttonFormatter
    }
  ];
  const rowEvents = {
    onClick: (e, row, rowIndex) => {
      alert(row.firstname);
    }
  };

  const onExport = e => {
    alert(`${e} export tıklandı`);
  };

  const onTableChange = (
    type,
    { page, sizePerPage, sortField, sortOrder },
    search
  ) => {
    setTableConfig({ page, sizePerPage, sortField, sortOrder, search });
  };

  useEffect(() => {
    getUsers(
      tableConfig.page,
      tableConfig.sizePerPage,
      tableConfig.sortField,
      tableConfig.sortOrder,
      tableConfig.search
    );
  }, [
    tableConfig.page,
    tableConfig.sizePerPage,
    tableConfig.sortField,
    tableConfig.sortOrder,
    tableConfig.search,
    getUsers
  ]);

  return (
    <div className="user-list">
      <div className="row">
        <div className="col-md-12">
          <ACSHBFrame
            title="Kullanıcı Yönetimi"
            color="primary"
            loading={loading}
          >
            <Link to="/kullanicilar/ekle" title="Kullanıcı Ekle">
              Kullanıcı Ekle
            </Link>
            <ACSHBDatatable
              onTableChange={onTableChange}
              searchCallback={search => {
                onTableChange(
                  "search",
                  {
                    page: tableConfig.page,
                    sizePerPage: tableConfig.sizePerPage,
                    sortField: tableConfig.sortField,
                    sortOrder: tableConfig.sortOrder
                  },
                  search
                );
              }}
              remote
              loading={loading}
              classes="table-responsive-md"
              keyField="id"
              data={response}
              columns={columns}
              bootstrap4
              rowEvents={rowEvents}
              noDataIndication={() => (
                <NoDataIndicator text="Veri bulunamadı." />
              )}
              exportCallback={onExport}
            />
          </ACSHBFrame>
        </div>
      </div>
    </div>
  );
};

const mapStateToProps = state => {
  return {
    response: state.user.response,
    loading: state.user.loading,
    error: state.user.error
  };
};

const mapDispatchToProps = dispatch => {
  return {
    getUsers: (page, sizePerPage, sortField, sortOrder, search) =>
      dispatch(searchUsers(page, sizePerPage, sortField, sortOrder, search))
  };
};

UserList.propTypes = {
  /**
   * redux getUsers methodu.
   */
  getUsers: PropTypes.func,
  /**
   * redux getUsers işlemi sürüyor mu?
   */
  loading: PropTypes.bool,
  /**
   * getUsers get response.
   */
  response: PropTypes.array,
  /**
   * getUsers get işleminde hata var ise hata obejesi.
   */
  error: PropTypes.object
};

UserList.defaultProps = {
  loading: false,
  response: [],
  error: null
};

export default connect(mapStateToProps, mapDispatchToProps)(UserList);
