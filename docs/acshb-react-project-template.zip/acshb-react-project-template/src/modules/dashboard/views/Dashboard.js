import React from "react";
import { useTranslation } from "react-i18next";
import { ACSHBFrame } from "acshb-react-common/components";
import ComponentSample from "../../../components/ComponentSample";
import "./style.scss";

const Dashboard = () => {
  const { i18n } = useTranslation();

  return (
    <div className="dashboard">
      <ACSHBFrame title="Dashboard" color="primary">
        <div className="row">
          <div className="col-md-12">
            <button type="button" onClick={() => i18n.changeLanguage("en-US")}>
              Dili Değiştir
            </button>
          </div>
          <div className="col-md-12">
            <ComponentSample />
          </div>
        </div>
      </ACSHBFrame>
    </div>
  );
};

export default Dashboard;
