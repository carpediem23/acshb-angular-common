import { lazy } from "react";

/**
 * Lazyload yapısı.
 */
const Dashboard = lazy(() => import("./views/Dashboard"));

export default Dashboard;
