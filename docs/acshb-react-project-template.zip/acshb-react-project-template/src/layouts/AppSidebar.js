import React, { forwardRef } from "react";
import { ACSHBSidebar } from "acshb-react-common/layouts";

// eslint-disable-next-line react/display-name
const AppSidebar = forwardRef((props, ref) => {
  return <ACSHBSidebar {...props} ref={ref} />;
});

export default AppSidebar;
