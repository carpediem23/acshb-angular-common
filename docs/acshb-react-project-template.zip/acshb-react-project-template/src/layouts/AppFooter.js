import React from "react";
import { ACSHBFooter } from "acshb-react-common/layouts";

const AppFooter = () => <ACSHBFooter className="bg-white text-center p-3 border-top" />;

export default AppFooter;
