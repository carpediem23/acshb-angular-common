import React from "react";
import { ACSHBToolbar } from "acshb-react-common/layouts";

const AppHeader = props => {
  return <ACSHBToolbar {...props} />;
};

export default AppHeader;
