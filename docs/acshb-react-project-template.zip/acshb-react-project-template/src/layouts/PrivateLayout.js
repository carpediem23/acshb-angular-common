import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Route, Switch } from "react-router-dom";
import { withTranslation } from "react-i18next";
import { ACSHBSection, ACSHBError } from "acshb-react-common/components";
import { language, logout } from "../actions";
import { UserService } from "../services";
import { AppHeader, AppSidebar, AppFooter } from "./";
import { Dashboard, Users } from "../modules/";
import routes from "../routes/routes.json";
import logo from "../assets/armali-logo-tr.svg";

const PrivateLayout = (props) => {
  const { logoutApp, t, setLanguage } = props;
  const sidebar = React.createRef();
  const toolbarItems = [
    {
      icon: "acshb-icon-arrow-right1",
      id: 0,
      title: "Seçenek 1",
      value: "0",
      callback: () => {
        console.log("Seçenek 1 Tıklandı");
      },
    },
    {
      icon: "acshb-icon-arrow-right1",
      id: 1,
      title: "Seçenek 2",
      value: "1",
    },
    {
      icon: "acshb-icon-settings",
      id: 2,
      title: "Ayarlar",
      value: "2",
    },
    {
      icon: "acshb-icon-log-out",
      id: 5,
      title: "Çıkış",
      value: "5",
      callback: () => onLogout(),
    },
    {
      icon: "acshb-icon-globe",
      id: 3,
      title: "English",
      value: "en-US",
      subItem: true,
      callback: () => {
        setLanguage("en-US");
      },
    },
    {
      icon: "acshb-icon-globe",
      id: 4,
      title: "Türkçe",
      value: "tr-TR",
      subItem: true,
      callback: () => {
        setLanguage("tr-TR");
      },
    },
  ];
  const user = UserService.getUser();

  const onToolbarItemClicked = (item) => {
    if (item.callback) item.callback();
  };

  const onLogout = () => logoutApp();

  return (
    <div className="private-layout">
      <AppHeader
        title={t("title")}
        className="bg-white shadow-sm"
        items={toolbarItems}
        logo={logo}
        elementClickedCallback={onToolbarItemClicked}
        fullname={user ? user.username : "username"}
        sidebarRef={sidebar}
      />
      <section className="d-flex">
        <AppSidebar
          ref={sidebar}
          className="border-right bg-white"
          routes={routes}
        />
        <ACSHBSection>
          <Switch>
            <Route exact path="/" component={Dashboard} />
            <Route path="/kullanicilar" component={Users} />
            <Route
              path="*"
              render={() => (
                <ACSHBError
                  logo={logo}
                  errorCode={parseInt(t("errors.404.code"), 10)}
                  errorTitle={t("errors.404.title")}
                  errorDescription={t("errors.404.description")}
                  gobackCallback={() => window.history.back()}
                />
              )}
            />
          </Switch>
        </ACSHBSection>
      </section>
      <AppFooter />
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    language: state.language,
    loading: state.loading,
    isSidebarOpen: state.sidebar,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    setLanguage: (lng) => dispatch(language(lng)),
    logoutApp: () => dispatch(logout()),
  };
};

PrivateLayout.propTypes = {
  /**
   * Uygulama geneli için redux loading durumu.
   */
  loading: PropTypes.bool,
  /**
   * Uygulama geneli için redux dil durumu.
   */
  language: PropTypes.string,
  /**
   * Uygulama geneli için redux dil değiştirme methodu.
   */
  setLanguage: PropTypes.func,
  /**
   * Translate methodu.
   */
  t: PropTypes.func,
  /**
   * Redux logout methodu.
   */
  logoutApp: PropTypes.func,
};

PrivateLayout.defaultProps = {
  loading: false,
  language: "tr-TR",
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withTranslation()(PrivateLayout));
