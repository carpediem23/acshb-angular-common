import React from "react";
import { Route, Switch, Redirect } from "react-router-dom";
import { Login } from "../modules";

const PublicLayout = () => (
  <div className="private-layout">
    <Switch>
      <Route exact path="/login" component={Login} />
      <Redirect from="*" to="/login" />
    </Switch>
  </div>
);

export default PublicLayout;
