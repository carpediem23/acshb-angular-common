/**
 * StorageService browser tabanlı depolama için kullanılır.
 * Default olarak sessionStorage nesnesini kullanır.
 *
 * @class
 * @example
 * import StorageService from "./services/StorageService";
 * StorageService.setItem("name", {name: "Alptuğ"});
 * const name = StorageService.getItem("name");
 * StorageService.deleteItem("name");
 */
const StorageService = {
  /**
   * Verilen değeri verilen isimle kaydeder.
   * @param {string} name   Hangi isimle kayıt edilecek.
   * @param {string} value  Kaydedilecek değer.
   */
  setItem(name, value) {
    sessionStorage.setItem(name, value);
  },
  /**
   * Verilen isimdeki değeri geri getirir.
   * @param   {string} name   Kayıt ismi.
   * @returns {object}
   */
  getItem(name) {
    return sessionStorage.getItem(name);
  },
  /**
   * Verilen isimdeki değeri siler.
   * @param {string} name   Kayıt ismi.
   */
  deleteItem(name) {
    return sessionStorage.removeItem(name);
  }
};

export default StorageService;
