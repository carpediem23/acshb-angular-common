import StorageService from "./StorageService";

/**
 * Kullanıcı servisi olarak kullanılır. Default olarak **universal-cookie** paketini kullanmaktadır.
 *
 * @class
 * @example
 * import UserService from "./services/userService";
 * UserService.setItem("name", {name: "Alptuğ", username: "alptug"});
 * const user = UserService.getItem();
 * UserService.deleteUser();
 */
const UserService = {
  /**
   * Verilen kullanıcı bilgilerini kaydeder.
   * @param {object} user Kullanıcı bilgileri JSON objesi.
   */
  setUser(user) {
    StorageService.setItem("user", JSON.stringify(user));
  },
  /**
   * Verilen kullanıcı bilgilerini kaydeder.
   * @returns {object} Geriye kullanıcıyı döndürür.
   */
  getUser() {
    return JSON.parse(StorageService.getItem("user"));
  },
  /**
   * Kullanıcı bilgilerini siler kaydeder.
   */
  deleteUser() {
    StorageService.deleteItem("user");
  }
};

export default UserService;
