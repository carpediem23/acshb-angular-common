import React from "react";
import PropTypes from "prop-types";
import { withTranslation } from "react-i18next";
import { useFetch } from "../hooks/useFetch";

/**
 * Lazy komponenti yükleme işlemi yaparken görüntülenecek olan komponenttir.
 *
 * @param {function} t      Çeviri için kullanılacak methodtur.
 * @param {function} i18n   Dili değiştirmek için kullanılacak methodtur.
 */
const ComponentSample = props => {
  const { t } = props;
  const [data, loading, error] = useFetch();

  console.log(data, loading, error);

  return loading ? <p>Yüleniyor...</p> : <div>{t("sample")}</div>;
};

ComponentSample.propTypes = {
  t: PropTypes.func,
  i18n: PropTypes.object
};

ComponentSample.defaultProps = {};

export default withTranslation()(ComponentSample);
