import React from "react";
import PropTypes from "prop-types";

/**
 * Veri yok gösterim komponentidir.
 *
 * @param {string} props Veri yok yazısı için kullanılacak parametredir.
 */
const NoDataIndicator = props => {
  return <p>{props.text}</p>;
};

NoDataIndicator.propTypes = {
  /**
   * Veri bulunamadı mesajı.
   */
  text: PropTypes.string.isRequired
};

NoDataIndicator.defaultProps = {
  text: "There is no data."
};

export default NoDataIndicator;
