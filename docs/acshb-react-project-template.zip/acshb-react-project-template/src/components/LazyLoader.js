import React from "react";

/**
 * LazyLoader komponenti, modüller yüklenirken görüntülenecek dom nesnesidir.
 */
const LazyLoader = () => {
  return <p>...</p>;
};

LazyLoader.propTypes = {};

LazyLoader.defaultProps = {};

export default LazyLoader;
