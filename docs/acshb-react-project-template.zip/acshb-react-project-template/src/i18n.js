import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import TR from "./locales/tr/lang.json";
import EN from "./locales/en/lang.json";

/**
 * Kaynak dil dosyaları.
 */
const resources = {
  tr: {
    translation: TR
  },
  en: {
    translation: EN
  }
};

/**
 * Initialize ve config methodları.
 */
i18n.use(initReactI18next).init({
  resources,
  lng: "tr",
  fallbackLng: "tr",
  interpolation: {
    escapeValue: false
  }
});

export default i18n;
