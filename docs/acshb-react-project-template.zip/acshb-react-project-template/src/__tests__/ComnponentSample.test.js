import React from "react";
import renderer from "react-test-renderer";
import ComponentSample from "../components/ComponentSample";

// eslint-disable-next-line no-undef
it("ComponentSample render oluyor.", () => {
  renderer.create(<ComponentSample />).toJSON();
});
