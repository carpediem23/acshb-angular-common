import { combineReducers } from "redux";
import { reducer as formReducer } from "redux-form";
import loading from "./loading";
import language from "./language";
import sidebar from "./sidebar";
import logout from "./logout";
import login from "../modules/login/business/reducer";
import user from "../modules/users/business/reducer";

/**
 * Ana redux reducer dosyası
 */
const rootReducer = combineReducers({
  form: formReducer,
  login,
  loading,
  language,
  sidebar,
  logout,
  user
});

export default rootReducer;
