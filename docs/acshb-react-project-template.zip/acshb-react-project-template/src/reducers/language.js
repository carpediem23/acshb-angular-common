/**
 * Uygulama bazında dil durumunu değiştirme işlemi için kullanılacak reducer.
 */
import * as types from "../actions/types";
import i18n from "../i18n";

const initialState = "tr-TR";

const language = (state = initialState, action) => {
  let result = null;

  switch (action.type) {
    case types.LANGUAGE:
      result = action.payload;
      i18n.changeLanguage(action.payload);
      break;
    default:
      result = state;
      break;
  }

  return result;
};

export default language;
