/**
 * Sidebar reducer.
 */
import * as types from "../actions/types";

const initialState = !(window.innerWidth <= 992);

const sidebar = (state = initialState, action) => {
  let result = null;

  switch (action.type) {
    case types.SIDEBAR:
      result = action.payload;
      break;
    default:
      result = state;
      break;
  }

  return result;
};

export default sidebar;
