/**
 * Logout reducer methodu.
 */
import * as types from "../actions/types";
import { UserService, TokenService } from "../services";

const initialState = {};

const logout = (state = initialState, action) => {
  switch (action.type) {
    case types.LOGOUT:
      UserService.deleteUser();
      TokenService.deleteToken();
      window.location.reload();
      break;
    default:
      break;
  }

  return null;
};

export default logout;
