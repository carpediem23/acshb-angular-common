import { useEffect, useState } from "react";
import { HttpService } from "../services";

/**
 * Fetch Hook Örneğidir.
 */
export function useFetch() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    HttpService.getRequest("/users")
      .then(response => {
        setUsers(response.data.items);
        setLoading(false);
      })
      .catch(error => {
        setError(error);
        setLoading(false);
      });
  }, []);

  return [users, loading, error];
}
