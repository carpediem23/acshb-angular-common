import React from "react";
import { PublicLayout, PrivateLayout } from "./layouts";
import { TokenService } from "./services";
import "./styles.scss";

const App = () => {
  const isAuth = TokenService.getToken();

  return (
    <div className="app">{isAuth ? <PrivateLayout /> : <PublicLayout />}</div>
  );
};

export default App;
