/**
 * Uygulama bazında loading durumunu değiştirme işlemi için kullanılacak action.
 */
import * as types from "./types";

const loading = loading => {
  return {
    type: types.LOADING,
    payload: loading
  };
};

export  default loading;
