import * as types from "./types";

/**
 * Sidebar komponentinin durumunu kontrol edecek olan action dosyasıdır.
 */
const sidebar = open => {
  return {
    type: types.SIDEBAR,
    payload: open
  };
};

export default sidebar;
