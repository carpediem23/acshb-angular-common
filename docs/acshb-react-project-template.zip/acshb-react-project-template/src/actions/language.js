/**
 * Uygulama bazında dil durumunu değiştirme işlemi için kullanılacak action.
 */
import * as types from "./types";

const language = language => {
  return {
    type: types.LANGUAGE,
    payload: language
  };
};

export default language;
