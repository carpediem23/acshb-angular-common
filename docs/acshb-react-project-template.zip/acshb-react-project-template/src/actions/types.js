/**
 * Action types.
 */
const LOADING = "LOADING";
const LANGUAGE = "LANGUAGE";
const SIDEBAR = "SIDEBAR";
const LOGOUT = "LOGOUT";

export { LOADING, LANGUAGE, SIDEBAR, LOGOUT };
