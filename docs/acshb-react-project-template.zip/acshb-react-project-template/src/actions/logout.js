/**
 * Logout action methodudur.
 */
import * as types from "./types";

const logout = () => {
  return {
    type: types.LOGOUT
  };
};

export default logout;
