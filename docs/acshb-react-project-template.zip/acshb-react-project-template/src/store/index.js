import { createStore, applyMiddleware } from "redux";
import thunk from "redux-thunk";
import { composeWithDevTools } from "redux-devtools-extension";
import rootReducer from "../reducers/root";

const initialState = {};
const middleware = [thunk];

/**
 * Ana store dosyasıdır.
 * async işlemler için redux-thunk kullanılmıştır.
 */
const store = createStore(
  rootReducer,
  initialState,
  composeWithDevTools(applyMiddleware(...middleware))
);

export default store;
